<?php
//add scripts

function cd_scripts(){
    //adding a css file and a js file 
    
    wp_enqueue_style('cd-main-style', plugins_url(). 'css/styles.css');
    
    
    wp_enqueue_script('cd-main-script', plugins_url(). 'js/styles.js');
}

add_action('wp_enqueue_scripts','cd_scripts');