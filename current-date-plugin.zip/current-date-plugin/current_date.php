<?php
/*
Plugin Name: Current-date-Plugin
Plugin URI: currentdate.com
Description: Checks if the current day/date is being displayed 
Version: 1.0
Author: Prim Ncube
Author URI: primncube.com
Text Domain: Current date/day check

*/


//block direct access if access via the url

/*if(!define('ABSPATH')){
    exit;
}*/



require_once(plugin_dir_path(__FILE__). '/includes/scripts.php');



require_once(plugin_dir_path(__FILE__). '/includes/cd_class.php');



function register_current_date(){
    register_widget('Current_date_Widget');
}

add_action('widgets_init', 'register_current_date');

