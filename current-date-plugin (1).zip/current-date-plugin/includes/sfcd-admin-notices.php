<?php
// If accessed directly, exit
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Class SFCD_Admin_Notices
 *
 *
 *
 *
 */
class SFCD_Admin_Notices {

	public static function init() {
		add_action( 'admin_notices', array( __CLASS__, 'review_notice' ), 20 );
		add_action( 'wp_ajax_sfcdReviewNoticeHide', array( __CLASS__, 'sfcd_hide_review_notify' ) );
	}
	
	public static function review_notice() {
        // Please rate us
        $install_date = get_option( 'sfcd_installDate' );
        $display_date = date( 'Y-m-d h:i:s' );
        $datetime1 = new DateTime( $install_date );
        $datetime2 = new DateTime( $display_date );
        $diff_intrval = round( ($datetime2->format( 'U' ) - $datetime1->format( 'U' )) / (60 * 60 * 24) );
		if ( $diff_intrval >= 14 && get_option( 'sfcd_review_notify' ) == "no" ) {
			?>
           
            <script>
                jQuery(document).ready(function ($) {
                    jQuery('.sfcd_HideReview_Notice').click(function () {
                        var data = {'action': 'sfcdReviewNoticeHide'};
                        jQuery.ajax({
                            url: "<?php echo admin_url( 'admin-ajax.php' ); ?>",
                            type: "post",
                            data: data,
                            dataType: "json",
                            async: !0,
                            success: function (notice_hide) {
                                if (notice_hide == "success") {
                                    jQuery('.sfcd-review-notice').slideUp('fast');
                                }
                            }
                        });
                    });
                });
            </script>
			<?php
		}
	}
	
	static function sfcd_hide_review_notify() {
		update_option( 'sfcd_review_notify', 'yes' );
		echo json_encode( array( "success" ) );
		exit;
	}
}