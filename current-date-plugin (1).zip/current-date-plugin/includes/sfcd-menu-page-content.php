<?php



// If accessed directly, exit
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$install_ub_url = \wp_nonce_url(
	\self_admin_url( 'update.php?action=install-plugin&plugin=ultimate-blocks' ),
	'install-plugin_ultimate-blocks'
);

?>

<div class="wrap about-wrap">

	<h1><?php printf( __( 'Shortcode for Current Date', 'sfcd' ) ); ?></h1>

	<div class="about-text">
		<?php printf( __( "This is just a simple shortcode plugin to display the date .
		Shortcode for Current Date is ready to show the current date, month and year for you. ", 'sfcd' ), '1.2.2' ); ?>
	</div>

	<div class="wp-badge welcome__logo"></div>

	<div class="col">
		<h3><?php _e( "How it works", 'sfcd' ); ?></h3>
		<p class="about-text">
			Either on a page or post copy and paste <strong>[current_date]</strong> where you want to show the date.</p>
	</div>



	

</div>
