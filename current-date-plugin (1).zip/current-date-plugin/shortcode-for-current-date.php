<?php

/**
 * Plugin Name: Current Date Display
 * Plugin URI: https://github.com/prim007/current-date-plugin
 * Description: Use a short code to display current date and time .
 * Version: 1.0.0
 * Author: Primrose Ncube
 * Author URI: https://github.com/prim007/current-date-plugin
 */

// If accessed directly, exit
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( !class_exists( 'Shortcode_For_Current_Date' ) ) {

	/**
	 * Current_Date. Contains everything.
	 *
	 
	 */
	class Shortcode_For_Current_Date {

		/**
		 * Current_Date constructor.
		 * 
		 *
		 * 
		 */
		public function __construct() {

			add_shortcode( 'current_date', array( $this, 'sfcd_date_shortcode' ) );

		}

		/**
		 * 
		 *
		 *
		 */
		public function sfcd_date_shortcode( $atts ) {

		
			$atts = shortcode_atts(
				array(
					'format' => '',
					'size' => '',
					'color' => ''
				), $atts
			);

			if ( !empty( $atts['format'] ) ) {
				$dateFormat = $atts['format'];
			} else {
				$dateFormat = 'jS F Y';
			}

			
			if ( !empty( $atts['size'] ) || !empty( $atts['color'] ) ) {
				if ( $dateFormat == 'z' ) {
					return "<p class='sfcd-date' style='font-size:" . $atts['size'] . "; color: " . $atts['color'] . ";'>" . ( date_i18n( $dateFormat ) + 1 ) . "</p>";
				} else {
					return "<p class='sfcd-date' style='font-size:" . $atts['size'] . "; color: " . $atts['color'] . ";'>" . date_i18n( $dateFormat ) . "</p>";
				}
			} else {
				if ( $dateFormat == 'z' ) {
					return date_i18n( $dateFormat ) + 1;
				} else {
					return date_i18n( $dateFormat );
				}
			}

			

		}

	}

}

/* Block Registration */
function Shortcode_For_Current_Date_Block_Register() {

	wp_register_script(
    	'shortcode-for-current-date-editor-script',
    	plugins_url('dist/editor.js', __FILE__),
    	array('wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor', 'wp-components', 'wp-date')
	);

	wp_register_script(
    	'shortcode-for-current-date-script',
    	plugins_url('dist/script.js', __FILE__),
    	array()
  	);


	if ( function_exists( 'register_block_type' ) ) {
		register_block_type('shortcode-for-current-date/block',
    		array_merge(
      			array(
        			'editor_script' => 'shortcode-for-current-date-editor-script',
        			'script' => 'shortcode-for-current-date-script'
      			)
    		)
 		);
	}
	

}
/* END Block Registration */

new Shortcode_For_Current_Date();
//Loop through the includes files to display welcome page
require_once plugin_dir_path( __FILE__ )  . '/includes/sfcd-welcome-page.php';
require_once plugin_dir_path( __FILE__ )  . '/includes/sfcd-menu-page.php';
require_once plugin_dir_path( __FILE__ )  . '/includes/sfcd-admin-notices.php';

SFCD_Welcome_Page::init();
SFCD_Menu_Page::init();
SFCD_Admin_Notices::init();

register_activation_hook( __FILE__, array( 'SFCD_Welcome_Page', 'sfcd_welcome_activate' ) );
register_deactivation_hook( __FILE__, array( 'SFCD_Welcome_Page', 'sfcd_welcome_deactivate' ) );

add_filter( 'the_title', 'do_shortcode' );
add_action( 'init', 'Shortcode_For_Current_Date_Block_Register' );

